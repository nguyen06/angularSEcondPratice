declare var $: any;

export class Semantic {

    initDropDown() {
        $('.ui.dropdown')
            .dropdown();
    }

    initAccoordion() {
        $('.ui.accordion')
            .accordion();
    }
}