import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-card-view',
  templateUrl: './card-view.component.html',
  styleUrls: ['./card-view.component.less']
})
export class CardViewComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
