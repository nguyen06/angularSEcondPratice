export interface Product{
    $key?: string;
    name: string;
    sku: string;
    price: string;
    description: string;
    imageUrl: string;
    flipImageUrl: string;
}