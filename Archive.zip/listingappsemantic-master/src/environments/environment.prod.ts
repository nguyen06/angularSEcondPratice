export const environment = {
  production: true,
  firebase: {
    apiKey: "AIzaSyA7ftY7QA9wyJutDNsusU4zo6U2sp9CIyE",
    authDomain: "listingapp-dca60.firebaseapp.com",
    databaseURL: "https://listingapp-dca60.firebaseio.com",
    projectId: "listingapp-dca60",
    storageBucket: "listingapp-dca60.appspot.com",
    messagingSenderId: "265444287618"
  }
};
