/* tslint:disable:no-unused-variable */

import { TestBed, async } from '@angular/core/testing';
import { UserListComponent } from './user-list.component';

describe('Component: UserList', () => {
  it('should create an instance', () => {
    let component = new UserListComponent();
    expect(component).toBeTruthy();
  });
});
